import iq.gis.poiexporter.core.*;
import java.io.File;
import java.util.*;

public class CoreTest {
    static int fails = 0;
    static void check(String name, double got, double want, double tol) {
        boolean ok = Math.abs(got - want) <= tol;
        if (!ok) fails++;
        System.out.printf("%s %-28s got=%.4f want=%.4f%n", ok ? "PASS" : "FAIL", name, got, want);
    }

    static double[] snyder(double latD, double lonD, int zone) {
        double a = 6378137.0, f = 1 / 298.257223563, k0 = 0.9996;
        double e2 = f * (2 - f), ep2 = e2 / (1 - e2), e4 = e2 * e2, e6 = e4 * e2;
        double phi = Math.toRadians(latD), lam = Math.toRadians(lonD), lam0 = Math.toRadians((zone - 1) * 6 - 180 + 3);
        double sp = Math.sin(phi), cp = Math.cos(phi), tp = Math.tan(phi);
        double N = a / Math.sqrt(1 - e2 * sp * sp), T = tp * tp, C = ep2 * cp * cp, A = (lam - lam0) * cp;
        double M = a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * phi)
                + (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * phi) - (35 * e6 / 3072) * Math.sin(6 * phi));
        double x = k0 * N * (A + (1 - T + C) * Math.pow(A, 3) / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * Math.pow(A, 5) / 120);
        double y = k0 * (M + N * tp * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * Math.pow(A, 4) / 24
                + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * Math.pow(A, 6) / 720));
        return new double[]{500000 + x, latD >= 0 ? y : y + 10000000};
    }
    public static void main(String[] a) throws Exception {
        Utm.Result r = Utm.fromLatLon(0, 3);
        check("CM equator E", r.easting, 500000, 1e-6);
        check("CM equator N", r.northing, 0, 1e-6);
        check("zone(3E)", r.zone, 31, 0);
        // Independent check: Snyder (USGS PP1395) series, valid within ~3 deg of the central meridian
        double[][] sn = {{33.3152,44.3661},{30.5,47.8},{36.34,43.13},{37.1,42.7},{29.9,46.2},{35.5,45.4},{48.8584,2.2945},{40.7488,-73.9854}};
        for (double[] p : sn) {
            Utm.Result u = Utm.fromLatLon(p[0], p[1]);
            double[] s2 = snyder(p[0], p[1], u.zone);
            check("snyder E " + p[0] + "," + p[1], u.easting, s2[0], 0.01);
            check("snyder N " + p[0] + "," + p[1], u.northing, s2[1], 0.01);
        }
        // Iraq zones
        check("Baghdad zone", Utm.zoneFor(44.3661), 38, 0);
        check("Basra zone", Utm.zoneFor(47.78), 38, 0);
        check("Mosul zone", Utm.zoneFor(43.13), 38, 0);
        check("Ramadi-west zone", Utm.zoneFor(38.9), 37, 0);
        check("Sulaymaniyah zone", Utm.zoneFor(45.43), 38, 0);
        check("Zakho zone", Utm.zoneFor(42.68), 38, 0);
        check("Khanaqin(east) zone", Utm.zoneFor(45.37), 38, 0);
        check("Mandali zone", Utm.zoneFor(45.55), 38, 0);
        check("East of 48E zone", Utm.zoneFor(48.3), 39, 0);
        // Round trip incl. southern hemisphere and far from CM
        double[][] pts = {{33.3152,44.3661},{30.5,47.8},{-33.9,18.4},{36.2,38.1},{-0.5,3.1},{60,-170}};
        for (double[] p : pts) {
            Utm.Result u = Utm.fromLatLon(p[0], p[1]);
            double[] b = Utm.toLatLon(u.zone, u.north, u.easting, u.northing);
            check("roundtrip lat", b[0], p[0], 1e-9);
            check("roundtrip lon", b[1], p[1], 1e-9);
        }
        Utm.Result bg = Utm.fromLatLon(33.3152, 44.3661);
        System.out.printf("Baghdad -> %s E=%.2f N=%.2f%n", bg.zoneLabel(), bg.easting, bg.northing);

        List<Poi> l = new ArrayList<>();
        Poi p = new Poi(); p.name = "مستشفى اليرموك التعليمي"; p.type = "hospital"; p.category = "مستشفى";
        p.nahiya = "الكرخ"; p.qadaa = "بغداد"; p.governorate = "بغداد"; p.lat = 33.2892; p.lon = 44.3544; l.add(p);
        p = new Poi(); p.name = "Test long name " + "ب".repeat(300); p.type = "school"; p.category = "School";
        p.governorate = "نينوى"; p.lat = 36.34; p.lon = 43.13; l.add(p);
        p = new Poi(); p.name = "West point"; p.lat = 33.0; p.lon = 38.9; l.add(p);
        File dir = new File(a[0]);
        ShapefileWriter.write(dir, "poi_test", l);
        System.out.println(fails == 0 ? "ALL UTM CHECKS PASSED" : fails + " FAILURES");
        System.exit(fails == 0 ? 0 : 1);
    }
}
