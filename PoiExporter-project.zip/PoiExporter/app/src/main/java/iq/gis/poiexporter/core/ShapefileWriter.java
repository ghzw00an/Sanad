package iq.gis.poiexporter.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Writes a point Shapefile (.shp/.shx/.dbf/.prj/.cpg).
 * Geometry is stored in WGS84 lon/lat (EPSG:4326). UTM X/Y/zone are attribute columns,
 * because one file can span several UTM zones and a shapefile has a single CRS.
 */
public final class ShapefileWriter {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private static final String PRJ =
            "GEOGCS[\"GCS_WGS_1984\",DATUM[\"D_WGS_1984\",SPHEROID[\"WGS_1984\",6378137.0,298.257223563]],"
                    + "PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]]";

    /** DBF columns: name, type, byte length, decimals. */
    static final String[] F_NAME = {"NAME", "TYPE", "CATEGORY", "NAHIYA", "QADAA", "GOVERNORAT", "UTM_ZONE", "X", "Y"};
    static final char[] F_TYPE = {'C', 'C', 'C', 'C', 'C', 'C', 'C', 'N', 'N'};
    static final int[] F_LEN = {200, 80, 100, 100, 100, 100, 4, 14, 14};
    static final int[] F_DEC = {0, 0, 0, 0, 0, 0, 0, 2, 2};

    private ShapefileWriter() {}

    /** Writes the parts into dir and returns the .shp file. */
    public static File write(File dir, String baseName, List<Poi> pois) throws IOException {
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("cannot create " + dir);
        File shp = new File(dir, baseName + ".shp");
        writeShpShx(shp, new File(dir, baseName + ".shx"), pois);
        writeDbf(new File(dir, baseName + ".dbf"), pois);
        writeText(new File(dir, baseName + ".prj"), PRJ);
        writeText(new File(dir, baseName + ".cpg"), "UTF-8");
        return shp;
    }

    /** Zips the shapefile parts into one stream. */
    public static void zipParts(File dir, String baseName, OutputStream out) throws IOException {
        ZipOutputStream zos = new ZipOutputStream(out);
        String[] exts = {"shp", "shx", "dbf", "prj", "cpg"};
        byte[] buf = new byte[8192];
        for (String ext : exts) {
            File f = new File(dir, baseName + "." + ext);
            zos.putNextEntry(new ZipEntry(f.getName()));
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            try {
                int n;
                while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
            } finally {
                in.close();
            }
            zos.closeEntry();
        }
        zos.finish();
        zos.flush();
    }

    private static void writeText(File f, String s) throws IOException {
        FileOutputStream o = new FileOutputStream(f);
        try {
            o.write(s.getBytes(UTF8));
        } finally {
            o.close();
        }
    }

    private static ByteBuffer header(int fileLenBytes, double[] bbox) {
        ByteBuffer b = ByteBuffer.allocate(100);
        b.order(ByteOrder.BIG_ENDIAN);
        b.putInt(9994);
        for (int i = 0; i < 5; i++) b.putInt(0);
        b.putInt(fileLenBytes / 2);
        b.order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(1000);
        b.putInt(1); // point
        for (double d : bbox) b.putDouble(d);
        b.putDouble(0).putDouble(0).putDouble(0).putDouble(0); // Z, M ranges
        return b;
    }

    private static void writeShpShx(File shp, File shx, List<Poi> pois) throws IOException {
        int n = pois.size();
        double minX = 0, minY = 0, maxX = 0, maxY = 0;
        for (int i = 0; i < n; i++) {
            Poi p = pois.get(i);
            if (i == 0) {
                minX = maxX = p.lon;
                minY = maxY = p.lat;
            } else {
                minX = Math.min(minX, p.lon);
                maxX = Math.max(maxX, p.lon);
                minY = Math.min(minY, p.lat);
                maxY = Math.max(maxY, p.lat);
            }
        }
        double[] bbox = {minX, minY, maxX, maxY};

        ByteBuffer shpBuf = ByteBuffer.allocate(100 + 28 * n);
        ByteBuffer shxBuf = ByteBuffer.allocate(100 + 8 * n);
        shpBuf.put(header(100 + 28 * n, bbox).array());
        shxBuf.put(header(100 + 8 * n, bbox).array());
        for (int i = 0; i < n; i++) {
            Poi p = pois.get(i);
            shpBuf.order(ByteOrder.BIG_ENDIAN);
            shpBuf.putInt(i + 1);
            shpBuf.putInt(10); // content length in 16-bit words (20 bytes)
            shpBuf.order(ByteOrder.LITTLE_ENDIAN);
            shpBuf.putInt(1);
            shpBuf.putDouble(p.lon);
            shpBuf.putDouble(p.lat);

            shxBuf.order(ByteOrder.BIG_ENDIAN);
            shxBuf.putInt((100 + 28 * i) / 2);
            shxBuf.putInt(10);
        }
        writeBytes(shp, shpBuf.array());
        writeBytes(shx, shxBuf.array());
    }

    private static void writeBytes(File f, byte[] data) throws IOException {
        FileOutputStream o = new FileOutputStream(f);
        try {
            o.write(data);
        } finally {
            o.close();
        }
    }

    /** Truncates to at most maxBytes of UTF-8 without cutting a character in half. */
    static byte[] fit(String s, int maxBytes) {
        if (s == null) s = "";
        byte[] raw = s.getBytes(UTF8);
        if (raw.length <= maxBytes) return raw;
        int end = maxBytes;
        while (end > 0 && (raw[end] & 0xC0) == 0x80) end--;
        byte[] out = new byte[end];
        System.arraycopy(raw, 0, out, 0, end);
        return out;
    }

    private static void writeDbf(File f, List<Poi> pois) throws IOException {
        int nf = F_NAME.length;
        int recLen = 1;
        for (int len : F_LEN) recLen += len;
        int headerLen = 32 + 32 * nf + 1;

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteBuffer h = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN);
        Calendar c = Calendar.getInstance();
        h.put((byte) 0x03);
        h.put((byte) (c.get(Calendar.YEAR) - 1900));
        h.put((byte) (c.get(Calendar.MONTH) + 1));
        h.put((byte) c.get(Calendar.DAY_OF_MONTH));
        h.putInt(pois.size());
        h.putShort((short) headerLen);
        h.putShort((short) recLen);
        out.write(h.array());

        for (int i = 0; i < nf; i++) {
            byte[] d = new byte[32];
            byte[] nm = F_NAME[i].getBytes(UTF8);
            System.arraycopy(nm, 0, d, 0, Math.min(10, nm.length));
            d[11] = (byte) F_TYPE[i];
            d[16] = (byte) F_LEN[i];
            d[17] = (byte) F_DEC[i];
            out.write(d);
        }
        out.write(0x0D);

        for (Poi p : pois) {
            Utm.Result u = Utm.fromLatLon(p.lat, p.lon);
            out.write(0x20);
            String[] text = {p.name, p.type, p.category, p.nahiya, p.qadaa, p.governorate, u.zoneLabel()};
            for (int i = 0; i < text.length; i++) writeChar(out, fit(text[i], F_LEN[i]), F_LEN[i]);
            writeNum(out, u.easting, F_LEN[7], F_DEC[7]);
            writeNum(out, u.northing, F_LEN[8], F_DEC[8]);
        }
        out.write(0x1A);
        writeBytes(f, out.toByteArray());
    }

    private static void writeChar(ByteArrayOutputStream out, byte[] v, int len) {
        out.write(v, 0, v.length);
        for (int i = v.length; i < len; i++) out.write(0x20);
    }

    private static void writeNum(ByteArrayOutputStream out, double v, int len, int dec) {
        String s = String.format(java.util.Locale.US, "%." + dec + "f", v);
        byte[] b = s.getBytes(UTF8);
        for (int i = b.length; i < len; i++) out.write(0x20); // right-aligned
        out.write(b, 0, Math.min(len, b.length));
    }
}
